/* Eclipse - main application logic: tasks, streak days, themes, navigation, calendar, colour picker, swipe gestures */

    let TOTAL_DAYS = parseInt(localStorage.getItem('streakDays') || '30', 10);
    if (!Number.isFinite(TOTAL_DAYS) || TOTAL_DAYS < 1) TOTAL_DAYS = 30;

    const drawer = document.getElementById('drawer');
    const streakModal = document.getElementById('streakModal');
    const dashboardModal = document.getElementById('dashboardModal');
    const themePaletteModal = document.getElementById('themePaletteModal');
    const deleteOptionsModal = document.getElementById('deleteOptionsModal');
    const confirmDeleteAllModal = document.getElementById('confirmDeleteAllModal');
    const submitModal = document.getElementById('submitModal');
    const addTaskModal = document.getElementById('addTaskModal');
    const streakAlertModal = document.getElementById('streakAlertModal');
    const newTaskInput = document.getElementById('newTaskInput');
    const overlay = document.getElementById('overlay');
    let restoreFlowTimer = null;
    const dayCounter = document.getElementById('dayCounter');
    const circleOuter = document.getElementById('circleOuter');

    /* ===== DAY RING ===== */
    const ringFill = document.getElementById('ringFill');
    const ringEdge = document.getElementById('ringEdge');
    const RING_CIRCUMFERENCE = 2 * Math.PI * 80;
    ringFill.style.strokeDasharray = RING_CIRCUMFERENCE;
    ringFill.style.strokeDashoffset = RING_CIRCUMFERENCE;

    function mixWithWhite(hex, amount) {
      const n = parseInt(hex.replace('#', ''), 16);
      const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
      const m = c => Math.round(c + (255 - c) * amount);
      return `rgb(${m(r)}, ${m(g)}, ${m(b)})`;
    }

    function relLum(hex) {
      const c = hexToRgb(hex) || [0, 0, 0];
      const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
      return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
    }

    // Keeps every accent-coloured thing readable: a black icon colour on the black glass (or a white one on
    // white glass) gets a contrasting outline / label, and text on an accent fill flips black <-> white.
    function applyContrast(root, accentHex) {
      const L = relLum(accentHex);
      const ink = isLightMode ? '#000000' : '#ffffff';
      const low = isLightMode ? L > 0.46 : L < 0.06;
      root.style.setProperty('--ink', ink);
      root.style.setProperty('--accent-fg', L > 0.45 ? '#000000' : '#ffffff');
      root.style.setProperty('--accent-fg-shadow', L > 0.45 ? 'none' : '0 1px 2px rgba(0, 0, 0, 0.35)');
      if (low) {
        root.style.setProperty('--accent-vis', ink);
        root.style.setProperty('--accent-stroke', ink);
      } else {
        root.style.removeProperty('--accent-vis');
        root.style.removeProperty('--accent-stroke');
      }
      root.classList.toggle('accent-low', low);
      root.classList.toggle('edge-strong', low && isLightMode);
      root.style.setProperty('--mode-text', root.style.getPropertyValue('--text-color'));
      root.style.setProperty('--mode-sub', root.style.getPropertyValue('--subtext-color'));
    }

    function mixWithBlack(hex, amount) {
      const n = parseInt(hex.replace('#', ''), 16);
      const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
      const m = c => Math.round(c * (1 - amount));
      return `rgb(${m(r)}, ${m(g)}, ${m(b)})`;
    }

    function applyRingColor(accentHex, endHex) {
      const n = parseInt(accentHex.replace('#', ''), 16);
      const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
      document.getElementById('ringStop1').setAttribute('stop-color', mixWithWhite(accentHex, 0.12));
      document.getElementById('ringStop2').setAttribute('stop-color', accentHex);
      document.getElementById('ringStop3').setAttribute('stop-color', endHex || mixWithWhite(accentHex, 0.35));
      document.documentElement.style.setProperty('--ring-glow', `rgba(${r}, ${g}, ${b}, 0.7)`);
    }
    const calendarGrid = document.getElementById('calendarGrid');

    const defaultTasks = [
      "Avoid screen",
      "No porn",
      "No sugar",
      "5M Jump",
      "3M Hang"
    ];

    let tasks = JSON.parse(localStorage.getItem('userTasks') || 'null');
    if (!Array.isArray(tasks)) tasks = defaultTasks.map(name => ({name, checklist: []}));
    tasks = tasks.map(t => typeof t === 'string' ? ({name:t, checklist:[]}) : ({name:String(t.name || 'Task'), checklist:Array.isArray(t.checklist) ? t.checklist.map(x => typeof x === 'string' ? ({name:x,done:false}) : ({name:String(x.name || 'Checklist'),done:!!x.done})) : []}));

    let highestUnlockedDay = parseInt(localStorage.getItem('highestUnlockedDay')) || 1;
    let currentDay = parseInt(localStorage.getItem('challengeDay')) || 1;

    let dayTaskHistory = JSON.parse(localStorage.getItem('dayTaskHistory') || '{}');

    let isSelectMode = false;
    let navDragging = false;
    let calendarSig = '';
    let activeTaskIndex = null;
    let activeChecklistIndex = null;
    let activeTab = 'home';
    let longPressTimer = null;
    let completedDays = JSON.parse(localStorage.getItem('completedDays') || '[]');

    const colorPresets = {
      black: { accent: '#6366f1' },
      white: { accent: '#4f46e5' },
      red: { accent: '#ef4444' },
      blue: { accent: '#3b82f6' },
      green: { accent: '#10b981' },
      yellow: { accent: '#eab308' }
    };

    function applyCustomPreset() {
      let ct = null;
      try { ct = JSON.parse(localStorage.getItem('customTheme')); } catch (e) {}
      if (ct && /^#[0-9a-f]{6}$/i.test(ct.a)) {
        colorPresets.custom = { accent: ct.a, end: (ct.mode === 'gradient' && /^#[0-9a-f]{6}$/i.test(ct.b)) ? ct.b : null, alpha: ct.al == null ? 1 : ct.al, endAlpha: ct.bl == null ? 1 : ct.bl };
      }
    }
    applyCustomPreset();

    let selectedColor = localStorage.getItem('appColorTheme') || 'black';
    let isLightMode = localStorage.getItem('isLightMode') === 'true';
    let newStreakMode = 'edit'; 

    function loadDayState(day) {
      if (!dayTaskHistory[day]) {
        dayTaskHistory[day] = {};
      }
      tasks.forEach((task, tIdx) => {
        if (!dayTaskHistory[day][tIdx]) {
          dayTaskHistory[day][tIdx] = {};
        }
        task.checklist.forEach((item, cIdx) => {
          if (typeof dayTaskHistory[day][tIdx][cIdx] === 'boolean') {
            item.done = dayTaskHistory[day][tIdx][cIdx];
          } else {
            item.done = false;
            dayTaskHistory[day][tIdx][cIdx] = false;
          }
        });
      });
    }

    function saveCurrentDayState() {
      if (!dayTaskHistory[currentDay]) {
        dayTaskHistory[currentDay] = {};
      }
      tasks.forEach((task, tIdx) => {
        dayTaskHistory[currentDay][tIdx] = {};
        task.checklist.forEach((item, cIdx) => {
          dayTaskHistory[currentDay][tIdx][cIdx] = !!item.done;
        });
      });
      localStorage.setItem('dayTaskHistory', JSON.stringify(dayTaskHistory));
    }

    function updateLiveSystemClock() {
      const now = new Date();
      let hours = now.getHours();
      hours = hours % 12;
      hours = hours ? hours : 12;
      const minutes = String(now.getMinutes()).padStart(2, '0');

      document.getElementById('dashLiveTime').textContent = `${hours}:${minutes}`;

      const daysShort = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
      const monthsShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

      const dayName = daysShort[now.getDay()];
      const monthName = monthsShort[now.getMonth()];
      const dateNum = now.getDate();

      document.getElementById('dashLiveDate').textContent = `${dayName}, ${monthName}. ${dateNum}`;
    }

    function renderMonthCalendar() {
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth();
      const todayDate = now.getDate();

      const monthNames = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
      document.getElementById('dashMonthTitle').textContent = monthNames[currentMonth];

      const firstDay = new Date(currentYear, currentMonth, 1).getDay();
      const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

      const tbody = document.getElementById('dashCalendarBody');
      tbody.innerHTML = '';

      let date = 1;
      for (let i = 0; i < 6; i++) {
        let row = document.createElement('tr');
        let hasDate = false;

        for (let j = 0; j < 7; j++) {
          let cell = document.createElement('td');
          if (i === 0 && j < firstDay) {
            cell.textContent = '';
          } else if (date > daysInMonth) {
            cell.textContent = '';
          } else {
            let dayBtn = document.createElement('div');
            dayBtn.className = 'day-cell-btn';
            if (date === todayDate) {
              dayBtn.classList.add('active');
            }
            dayBtn.textContent = date;
            cell.appendChild(dayBtn);
            date++;
            hasDate = true;
          }
          row.appendChild(cell);
        }
        if (hasDate || i === 0) {
          tbody.appendChild(row);
        }
      }
    }

    function openDashboardModal() {
      closeAll();
      updateLiveSystemClock();
      renderMonthCalendar();
      dashboardModal.classList.add('open');
      overlay.classList.add('active');
    }

    setInterval(updateLiveSystemClock, 1000);

    function escapeHtml(value) {
      return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
    }

    function attachLongPress(el, callback) {
      const start = (e) => { 
        clearTimeout(longPressTimer); 
        longPressTimer = setTimeout(() => {
          if (navigator.vibrate) navigator.vibrate(40);
          callback();
        }, 600); 
      };
      const cancel = () => { clearTimeout(longPressTimer); longPressTimer = null; };
      el.addEventListener('touchstart', start, {passive:true});
      el.addEventListener('touchend', cancel, {passive:true});
      el.addEventListener('touchmove', cancel, {passive:true});
      el.addEventListener('mousedown', start);
      el.addEventListener('mouseup', cancel);
      el.addEventListener('mouseleave', cancel);
    }

    function renderTasks() {
      if (typeof scheduleSoon === 'function') scheduleSoon();
      loadDayState(currentDay);
      const homeTaskList = document.getElementById('homeTaskList');
      const allTaskList = document.getElementById('allTaskList');
      const savedHomeScroll = homeTaskList.scrollTop;
      const savedAllScroll = allTaskList.scrollTop;
      homeTaskList.innerHTML = '';
      allTaskList.innerHTML = '';

      tasks.forEach((task, index) => {
        const allDone = task.checklist.length > 0 && task.checklist.every(x => x.done);
        const checked = allDone ? 'checked' : '';
        const homeItem = document.createElement('li');
        homeItem.className = 'task-item';
        homeItem.innerHTML = `<div class="task-parent-row"><div class="task-name-wrap"><span class="task-label">${escapeHtml(task.name)}</span><div class="manage-hint">Tap to view checklist</div></div><input type="checkbox" class="task-checkbox" data-index="${index}" ${checked} disabled></div>`;
        homeItem.addEventListener('click', () => openChecklist(index, false));
        homeTaskList.appendChild(homeItem);

        const allItem = document.createElement('li');
        allItem.className = 'task-item';
        if (isSelectMode) {
          allItem.innerHTML = `<div class="task-parent-row"><div class="task-name-wrap"><span class="task-label">${escapeHtml(task.name)}</span><div class="manage-hint">Select to delete</div></div><input type="checkbox" class="delete-select-checkbox" data-index="${index}"></div>`;
          const box = allItem.querySelector('.delete-select-checkbox');
          allItem.addEventListener('click', e => { if (e.target !== box) box.checked = !box.checked; });
        } else {
          allItem.innerHTML = `<div class="task-parent-row"><div class="task-name-wrap"><span class="task-label">${escapeHtml(task.name)}</span><div class="manage-hint">Tap to open • hold to edit</div></div><input type="checkbox" class="task-checkbox" data-index="${index}" ${checked} disabled></div>`;
          allItem.addEventListener('click', () => openChecklist(index, true));
          attachLongPress(allItem, () => openParentOptions(index));
        }
        allTaskList.appendChild(allItem);
      });
      homeTaskList.scrollTop = savedHomeScroll;
      allTaskList.scrollTop = savedAllScroll;
      syncAddButtonVisibility();
      updateTaskStats();
    }

    /* Handler for the floating liquid glass button physics trigger */
    function handleFloatingButtonClick() {  
      const btn = document.getElementById('glassButton');  
      btn.classList.remove('liquid-active');  
      void btn.offsetWidth; // Force reflow  
      btn.classList.add('liquid-active');  
      
      openAddTaskModal();
    }

    function openParentOptions(index) {
      if (activeTab !== 'tasks' || !tasks[index]) return;
      if (restoreFlowTimer) { clearTimeout(restoreFlowTimer); restoreFlowTimer = null; }
      document.getElementById('newStreakModal')?.classList.remove('open');
      activeTaskIndex = index;
      document.getElementById('parentOptionsTitle').textContent = tasks[index].name;
      closeAll();
      document.getElementById('parentOptionsModal').classList.add('open');
      overlay.classList.add('active');
    }

    function openEditTaskModal() {
      if (activeTaskIndex === null || !tasks[activeTaskIndex]) return;
      closeAll();
      document.getElementById('newStreakModal')?.classList.remove('open');
      overlay.classList.remove('active');
      document.getElementById('editTaskInput').value = tasks[activeTaskIndex].name;
      document.getElementById('editTaskModal').classList.add('open');
      overlay.classList.add('active');
      setTimeout(() => document.getElementById('editTaskInput').focus(), 150);
    }

    function saveEditedTask() {
      if (activeTaskIndex === null || !tasks[activeTaskIndex]) return;
      if (document.activeElement && typeof document.activeElement.blur === 'function') document.activeElement.blur();
      const name = document.getElementById('editTaskInput').value.trim();
      if (!name) return;
      tasks[activeTaskIndex].name = name;
      saveAndReloadTasks();
      closeAll();
    }

    function openChecklist(taskIndex, allowManagement) {
      if (!tasks[taskIndex]) return;
      activeTaskIndex = taskIndex;
      document.getElementById('checklistModalTitle').textContent = tasks[taskIndex].name;
      document.getElementById('addChecklistItemBtn').style.display = allowManagement ? 'flex' : 'none';
      document.getElementById('checklistManageHint').style.display = allowManagement ? 'block' : 'none';
      document.getElementById('checklistModal').dataset.manage = allowManagement ? 'true' : 'false';
      closeAll();
      document.getElementById('checklistModal').classList.add('open');
      overlay.classList.add('active');
      renderChecklist();
    }

    function renderChecklist() {
      const list = document.getElementById('checklistList');
      list.innerHTML = '';
      if (activeTaskIndex === null || !tasks[activeTaskIndex]) return;
      const items = tasks[activeTaskIndex].checklist;
      if (!items.length) { list.innerHTML = '<div class="empty-state">No checklist items yet.</div>'; return; }
      items.forEach((item, index) => {
        const li = document.createElement('div');
        li.className = 'checklist-item';
        li.innerHTML = `<input type="checkbox" ${item.done ? 'checked':''} data-index="${index}"><span>${escapeHtml(item.name)}</span>`;
        li.querySelector('input').addEventListener('change', e => {
          item.done = e.target.checked;
          saveCurrentDayState();
          saveAndReloadTasks();
          renderChecklist();
          if (activeTab === 'home' && tasks[activeTaskIndex].checklist.length && tasks[activeTaskIndex].checklist.every(x=>x.done)) {
            closeAll();
            checkAllTasksForDay();
          }
        });
        if (document.getElementById('checklistModal').dataset.manage === 'true') attachLongPress(li, () => openChecklistItemOptions(index));
        list.appendChild(li);
      });
    }

    function openAddChecklistItemModal() {
      if (activeTab !== 'tasks' || document.getElementById('checklistModal').dataset.manage !== 'true') return;
      closeAll();
      document.getElementById('newStreakModal')?.classList.remove('open');
      overlay.classList.remove('active');
      document.getElementById('checklistItemModalTitle').textContent = 'Add Checklist Item';
      document.getElementById('checklistItemInput').value = '';
      document.getElementById('checklistItemModal').dataset.mode = 'add';
      document.getElementById('checklistItemModal').classList.add('open');
      overlay.classList.add('active');
      setTimeout(() => document.getElementById('checklistItemInput').focus(), 150);
    }

    function openChecklistItemOptions(index) {
      if (activeTab !== 'tasks' || activeTaskIndex === null || !tasks[activeTaskIndex]?.checklist[index]) return;
      activeChecklistIndex = index;
      document.getElementById('checklistItemOptionsTitle').textContent = tasks[activeTaskIndex].checklist[index].name;
      closeAll();
      document.getElementById('checklistItemOptionsModal').classList.add('open');
      overlay.classList.add('active');
    }

    function openEditChecklistItem() {
      if (activeTaskIndex === null || activeChecklistIndex === null) return;
      const item = tasks[activeTaskIndex].checklist[activeChecklistIndex];
      if (!item) return;
      closeAll();
      document.getElementById('newStreakModal')?.classList.remove('open');
      overlay.classList.remove('active');
      document.getElementById('checklistItemModalTitle').textContent = 'Edit Checklist Item';
      document.getElementById('checklistItemInput').value = item.name;
      document.getElementById('checklistItemModal').dataset.mode = 'edit';
      document.getElementById('checklistItemModal').classList.add('open');
      overlay.classList.add('active');
      setTimeout(() => document.getElementById('checklistItemInput').focus(), 150);
    }

    function saveChecklistItem() {
      if (activeTaskIndex === null) return;
      if (document.activeElement && typeof document.activeElement.blur === 'function') document.activeElement.blur();
      const name = document.getElementById('checklistItemInput').value.trim();
      if (!name) return;
      const mode = document.getElementById('checklistItemModal').dataset.mode;
      if (mode === 'edit' && activeChecklistIndex !== null && tasks[activeTaskIndex].checklist[activeChecklistIndex]) {
        tasks[activeTaskIndex].checklist[activeChecklistIndex].name = name;
      } else {
        tasks[activeTaskIndex].checklist.push({name, done:false});
      }
      saveCurrentDayState();
      saveAndReloadTasks();
      reopenChecklistModal();
    }

    function reopenChecklistModal() {
      if (activeTaskIndex !== null && tasks[activeTaskIndex]) {
        openChecklist(activeTaskIndex, true);
      } else {
        closeAll();
      }
    }

    function confirmDeleteChecklistItem() {
      if (activeTaskIndex === null || activeChecklistIndex === null) return;
      const item = tasks[activeTaskIndex].checklist[activeChecklistIndex];
      if (!item) return;
      document.getElementById('deleteChecklistConfirmText').textContent = `Delete “${item.name}”?`;
      closeAll();
      document.getElementById('deleteChecklistConfirmModal').classList.add('open');
      overlay.classList.add('active');
    }

    function deleteChecklistItem() {
      if (activeTaskIndex === null || activeChecklistIndex === null) return;
      tasks[activeTaskIndex].checklist.splice(activeChecklistIndex, 1);
      saveCurrentDayState();
      saveAndReloadTasks();
      reopenChecklistModal();
    }

    function checkAllTasksForDay() {
      const allDone = tasks.length > 0 && tasks.every(t => t.checklist.length > 0 && t.checklist.every(x=>x.done));
      if (!allDone) return;
      openSubmitModal();
    }

    function openSubmitModal() {
      closeAll();
      submitModal.classList.add('open');
      overlay.classList.add('active');
    }

    function confirmProgressNextDay() {
      saveCurrentDayState();
      completedDays = Array.from(new Set([...completedDays, currentDay])).sort((a,b)=>a-b);
      localStorage.setItem('completedDays', JSON.stringify(completedDays));
      const finishedDay = currentDay;
      if (finishedDay >= TOTAL_DAYS) {
        closeAll();
        showFinalReward();
        return;
      }
      currentDay = finishedDay + 1;
      highestUnlockedDay = Math.max(highestUnlockedDay, currentDay);
      localStorage.setItem('highestUnlockedDay', highestUnlockedDay);
      renderProgress();
      renderTasks();
      closeAll();
    }

    function cancelProgressModal() {
      closeAll();
    }

    function selectDay(targetDay) {
      if (targetDay > highestUnlockedDay) {
        openStreakAlertModal();
      } else {
        saveCurrentDayState();
        currentDay = targetDay;
        renderProgress();
        renderTasks();
        closeAll();
        switchTab('home');
      }
    }

    function openStreakAlertModal() {
      streakAlertModal.classList.add('open');
      overlay.classList.add('active');
    }

    function closeStreakAlertModal() {
      streakAlertModal.classList.remove('open');
      overlay.classList.remove('active');
      streakModal.classList.add('open');
      buildStreakCalendar();
    }

    function applyCombinedTheme() {
      const root = document.documentElement;
      const preset = colorPresets[selectedColor] || colorPresets.black;
      const accentCss = (preset.alpha != null && preset.alpha < 1) ? rgbaOf(preset.accent, preset.alpha) : preset.accent;
      const endCss = preset.end ? rgbaOf(preset.end, preset.endAlpha == null ? 1 : preset.endAlpha) : mixWithBlack(preset.accent, 0.42);

      if (isLightMode) {
        root.style.setProperty('--bg-color', '#f8fafc');
        root.style.setProperty('--card-bg', 'rgba(255, 255, 255, 0.7)');
        root.style.setProperty('--modal-bg', 'rgba(255, 255, 255, 0.95)');
        root.style.setProperty('--text-color', '#0f172a');
        root.style.setProperty('--subtext-color', '#475569');
        root.style.setProperty('--border-color', 'rgba(0, 0, 0, 0.12)');
        root.style.setProperty('--item-bg', 'rgba(0,0,0,0.045)');
        root.style.setProperty('--circle-track', 'rgba(0,0,0,0.12)');
        root.style.setProperty('--accent-color', accentCss);
        root.style.setProperty('--modal-border-color', 'rgba(0, 0, 0, 0.15)');
        root.style.setProperty('--nav-glass-bg', 'rgba(255, 255, 255, 0.82)');
        root.style.setProperty('--streak-edit-glass-bg', 'rgba(255, 255, 255, 0.85)');
        root.style.setProperty('--number-color', '#000000');
      } else {
        root.style.setProperty('--bg-color', '#000000');
        root.style.setProperty('--card-bg', 'rgba(18, 24, 38, 0.65)');
        root.style.setProperty('--modal-bg', 'rgba(20, 20, 25, 0.95)');
        root.style.setProperty('--text-color', '#ffffff');
        root.style.setProperty('--subtext-color', 'rgba(255, 255, 255, 0.55)');
        root.style.setProperty('--border-color', 'rgba(255, 255, 255, 0.15)');
        root.style.setProperty('--item-bg', 'rgba(255, 255, 255, 0.08)');
        root.style.setProperty('--circle-track', '#222222');
        root.style.setProperty('--accent-color', accentCss);
        root.style.setProperty('--modal-border-color', 'rgba(255, 255, 255, 0.2)');
        root.style.setProperty('--nav-glass-bg', '#0c1019');
        root.style.setProperty('--streak-edit-glass-bg', '#000000');
        root.style.setProperty('--number-color', '#ffffff');
      }

      document.documentElement.classList.toggle('dark-glass-lock', !isLightMode);
      document.documentElement.classList.toggle('light-glass', isLightMode);
      root.style.setProperty('--accent-end', endCss);
      applyBackgroundTheme(root);
      applyContrast(root, preset.accent);
      applyRingColor(preset.accent, preset.end);
      document.getElementById('themeToggle').checked = isLightMode;
      if (typeof syncModeToggle === 'function') syncModeToggle();
      localStorage.setItem('appColorTheme', selectedColor);
      localStorage.setItem('isLightMode', isLightMode);

      renderProgress();
      if (dashboardModal.classList.contains('open')) renderMonthCalendar();
    }



    /* ===== BACKGROUND THEME (dark mode) ===== */
    const BG_PRESETS = { white: '#f8fafc', black: '#000000', midnight: '#0a1226', graphite: '#232327', forest: '#0c2a1b', plum: '#2a0f22', wine: '#2e1010' };

    function readBgTheme() {
      try { return JSON.parse(localStorage.getItem('bgTheme')); } catch (e) { return null; }
    }

    function applyBackgroundTheme(root) {
      const keys = ['--page-fill', '--surf-fill', '--tasks-fill', '--surf-modal'];
      const t = readBgTheme();
      let a = null, b = null, al = 1, bl = 1;
      if (t && t.id === 'custom' && /^#[0-9a-f]{6}$/i.test(t.a)) {
        a = t.a; al = t.al == null ? 1 : t.al;
        if (t.mode === 'gradient' && /^#[0-9a-f]{6}$/i.test(t.b)) { b = t.b; bl = t.bl == null ? 1 : t.bl; }
      } else if (t && BG_PRESETS[t.id]) { a = BG_PRESETS[t.id]; }
      if (!a) { keys.forEach(k => root.style.removeProperty(k)); root.style.removeProperty('--panel-text'); root.style.removeProperty('--panel-sub'); return; }
      const lumPanel = b ? (relLum(a) + relLum(b)) / 2 : relLum(a);
      const panelDark = lumPanel < 0.4;
      root.style.setProperty('--panel-text', panelDark ? '#ffffff' : '#0f172a');
      root.style.setProperty('--panel-sub', panelDark ? 'rgba(255, 255, 255, 0.55)' : '#475569');
      const light = (hex, alpha) => {            // slightly lighter version used for the panels
        const n = parseInt(hex.slice(1), 16);
        const m = c => Math.round(c + (255 - c) * (isLightMode ? 0 : 0.07));
        return rgbaOf(rgbToHex(m((n >> 16) & 255), m((n >> 8) & 255), m(n & 255)), alpha);
      };
      const page = b ? `linear-gradient(to bottom, ${rgbaOf(a, al)}, ${rgbaOf(b, bl)})` : rgbaOf(a, al);
      const surf = b ? `linear-gradient(to bottom, ${light(a, al)}, ${light(b, bl)})` : light(a, al);
      root.style.setProperty('--page-fill', page);
      root.style.setProperty('--surf-fill', surf);
      root.style.setProperty('--surf-modal', surf);
      root.style.removeProperty('--tasks-fill');
    }

    function selectBackground(id) {
      localStorage.setItem('bgTheme', JSON.stringify({ id }));
      runThemeSwitch(() => applyCombinedTheme());
      closeAll();
    }

    function openThemeChooser() {
      closeAll();
      document.getElementById('themeChooserModal').classList.add('open');
      overlay.classList.add('active');
    }

    function openBackgroundPalette() {
      closeAll();
      document.getElementById('bgPaletteModal').classList.add('open');
      overlay.classList.add('active');
    }

    function updateCustomBgTile() {
      const tile = document.getElementById('customBgTilePreview');
      const t = readBgTheme();
      if (tile && t && t.id === 'custom' && t.a) {
        const ca = rgbaOf(t.a, t.al == null ? 1 : t.al), cb2 = t.b ? rgbaOf(t.b, t.bl == null ? 1 : t.bl) : null;
        tile.style.background = (t.mode === 'gradient' && cb2) ? `linear-gradient(to bottom, ${ca}, ${cb2})` : ca;
        tile.textContent = '';
      }
    }

    /* ===== CUSTOM COLOUR (solid / gradient) ===== */
    const DEFAULT_SAVED = ['#ff3636', '#ff8a1f', '#ffe436', '#a21caf', '#ff7a7a', '#a8a29e', '#bef264', '#7f1d1d', '#0f1b46', '#3b0a0a', '#6b21a8', '#3f6212', '#1e90a0'];
    let savedColors;
    try { savedColors = JSON.parse(localStorage.getItem('savedColors')); } catch (e) {}
    if (!Array.isArray(savedColors)) savedColors = DEFAULT_SAVED.slice();

    const cc = { mode: 'solid', active: 0, stops: [{ h: 240, s: 0.7, v: 0.65, al: 1 }, { h: 0, s: 0, v: 0, al: 1 }] };

    function hsv2rgb(h, s, v) {
      const f = (n) => { const k = (n + h / 60) % 6; return v - v * s * Math.max(Math.min(k, 4 - k, 1), 0); };
      return [Math.round(f(5) * 255), Math.round(f(3) * 255), Math.round(f(1) * 255)];
    }

    function rgb2hsv(r, g, b) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
      let h = 0;
      if (d) {
        if (max === r) h = ((g - b) / d) % 6; else if (max === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        h *= 60; if (h < 0) h += 360;
      }
      return { h, s: max ? d / max : 0, v: max };
    }

    function rgb2hsl(r, g, b) {
      r /= 255; g /= 255; b /= 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2, d = max - min;
      let h = 0, s = 0;
      if (d) {
        s = d / (1 - Math.abs(2 * l - 1));
        if (max === r) h = ((g - b) / d) % 6; else if (max === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        h *= 60; if (h < 0) h += 360;
      }
      return [Math.round(h), Math.round(s * 100), Math.round(l * 100)];
    }

    function hsl2rgb(h, s, l) {
      s /= 100; l /= 100;
      const a = s * Math.min(l, 1 - l);
      const f = (n) => { const k = (n + h / 30) % 12; return l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1); };
      return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255)];
    }

    const rgbToHex = (r, g, b) => '#' + [r, g, b].map(x => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0')).join('');

    function hexToRgb(hex) {
      const m = /^#?([0-9a-f]{6})$/i.exec(String(hex).trim());
      if (!m) return null;
      const n = parseInt(m[1], 16);
      return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    }

    function ccHexOf(i) { const st = cc.stops[i]; return rgbToHex(...hsv2rgb(st.h, st.s, st.v)); }

    function rgbaOf(hex, a) {
      const c = hexToRgb(hex) || [0, 0, 0];
      return a >= 1 ? hex : `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${Math.round(a * 100) / 100})`;
    }

    function ccCssOf(i) { return rgbaOf(ccHexOf(i), cc.stops[i].al == null ? 1 : cc.stops[i].al); }
    const CHECKER = 'repeating-conic-gradient(#8a8a8a 0% 25%, #cfcfcf 0% 50%) 50% / 12px 12px';

    const ccEls = {
      sv: document.getElementById('ccSV'), knob: document.getElementById('ccKnob'), hue: document.getElementById('ccHue'),
      preview: document.getElementById('ccPreview'), fmt: document.getElementById('ccFormat'), hex: document.getElementById('ccHex'),
      n: [document.getElementById('ccN1'), document.getElementById('ccN2'), document.getElementById('ccN3')],
      saved: document.getElementById('ccSaved'), stops: document.getElementById('ccStops'), alpha: document.getElementById('ccAlpha')
    };

    function ccRender(skipFields) {
      const st = cc.stops[cc.active];
      ccEls.sv.style.setProperty('--cc-h', Math.round(st.h));
      ccEls.knob.style.left = (st.s * 100) + '%';
      ccEls.knob.style.top = ((1 - st.v) * 100) + '%';
      ccEls.hue.value = Math.round(st.h);
      const hex = ccHexOf(cc.active);
      ccEls.preview.style.background = (cc.mode === 'gradient'
        ? `linear-gradient(to bottom, ${ccCssOf(0)}, ${ccCssOf(1)})` : `linear-gradient(${ccCssOf(0)}, ${ccCssOf(0)})`) + ', ' + CHECKER;
      document.getElementById('ccDotTop').style.background = ccCssOf(0);
      document.getElementById('ccDotBot').style.background = ccCssOf(1);
      const alPct = Math.round((st.al == null ? 1 : st.al) * 100);
      ccEls.alpha.value = alPct;
      ccEls.alpha.style.setProperty('--cc-color', hex);
      document.getElementById('ccAlphaVal').textContent = alPct + '%';
      document.getElementById('ccTabSolid').classList.toggle('active', cc.mode === 'solid');
      document.getElementById('ccTabGrad').classList.toggle('active', cc.mode === 'gradient');
      ccEls.stops.style.display = cc.mode === 'gradient' ? 'flex' : 'none';
      document.getElementById('ccStopTop').classList.toggle('active', cc.active === 0);
      document.getElementById('ccStopBot').classList.toggle('active', cc.active === 1);

      if (skipFields) return;
      const fmt = ccEls.fmt.value;
      const rgb = hsv2rgb(st.h, st.s, st.v);
      ccEls.hex.style.display = fmt === 'hex' ? '' : 'none';
      ccEls.n.forEach(n => n.style.display = fmt === 'hex' ? 'none' : '');
      if (fmt === 'hex') ccEls.hex.value = hex;
      else if (fmt === 'rgb') ccEls.n.forEach((n, i) => { n.value = rgb[i]; n.min = 0; n.max = 255; });
      else { const hsl = rgb2hsl(...rgb); ccEls.n.forEach((n, i) => { n.value = hsl[i]; n.min = 0; n.max = i === 0 ? 360 : 100; }); }
    }

    function ccSetRgb(r, g, b) {
      const hsv = rgb2hsv(r, g, b);
      const st = cc.stops[cc.active];
      st.h = (hsv.s === 0 || hsv.v === 0) ? st.h : hsv.h;   // keep the hue when the colour is grey/black
      st.s = hsv.s; st.v = hsv.v;
    }

    function ccSetMode(m) { cc.mode = m; if (m === 'solid') cc.active = 0; ccRender(); }
    function ccPickStop(i) { cc.active = i; ccRender(); }

    function ccRenderSaved() {
      ccEls.saved.innerHTML = '';
      savedColors.forEach((hex, i) => {
        const d = document.createElement('div');
        d.className = 'cc-swatch';
        d.style.background = hex;
        let timer = null, held = false;
        d.addEventListener('pointerdown', () => {
          held = false;
          timer = setTimeout(() => { held = true; savedColors.splice(i, 1); localStorage.setItem('savedColors', JSON.stringify(savedColors)); ccRenderSaved(); }, 650);
        });
        const up = () => { clearTimeout(timer); };
        d.addEventListener('pointerup', () => { up(); if (!held) { const rgb = hexToRgb(hex); if (rgb) { ccSetRgb(...rgb); ccRender(); } } });
        d.addEventListener('pointerleave', up);
        d.addEventListener('pointercancel', up);
        ccEls.saved.appendChild(d);
      });
      const add = document.createElement('div');
      add.className = 'cc-swatch add';
      add.textContent = '+';
      add.addEventListener('click', () => {
        const hex = ccHexOf(cc.active);
        if (!savedColors.includes(hex)) { savedColors.push(hex); localStorage.setItem('savedColors', JSON.stringify(savedColors)); ccRenderSaved(); }
      });
      ccEls.saved.appendChild(add);
    }

    (function initPicker() {
      let dragging = false;
      function fromPointer(e) {
        const r = ccEls.sv.getBoundingClientRect();
        const st = cc.stops[cc.active];
        st.s = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
        st.v = 1 - Math.max(0, Math.min(1, (e.clientY - r.top) / r.height));
        ccRender(true);
      }
      ccEls.sv.addEventListener('pointerdown', (e) => { dragging = true; try { ccEls.sv.setPointerCapture(e.pointerId); } catch (err) {} fromPointer(e); });
      ccEls.sv.addEventListener('pointermove', (e) => { if (dragging) fromPointer(e); });
      ccEls.sv.addEventListener('pointerup', () => { dragging = false; ccRender(); });
      ccEls.sv.addEventListener('pointercancel', () => { dragging = false; });

      ccEls.hue.addEventListener('input', () => { cc.stops[cc.active].h = Number(ccEls.hue.value); ccRender(true); });
      ccEls.hue.addEventListener('change', () => ccRender());
      ccEls.alpha.addEventListener('input', () => { cc.stops[cc.active].al = Number(ccEls.alpha.value) / 100; ccRender(true); });
      ccEls.alpha.addEventListener('change', () => ccRender());
      ccEls.fmt.addEventListener('change', () => ccRender());

      ccEls.hex.addEventListener('input', () => {
        let v = ccEls.hex.value.trim();
        if (v && v[0] !== '#') v = '#' + v;
        const rgb = hexToRgb(v);
        if (rgb) { ccSetRgb(...rgb); ccRender(true); }
      });

      ccEls.n.forEach(inp => inp.addEventListener('input', () => {
        const a = ccEls.n.map(n => Number(n.value) || 0);
        const rgb = ccEls.fmt.value === 'rgb'
          ? a.map(x => Math.max(0, Math.min(255, x)))
          : hsl2rgb(Math.max(0, Math.min(360, a[0])), Math.max(0, Math.min(100, a[1])), Math.max(0, Math.min(100, a[2])));
        ccSetRgb(...rgb);
        ccRender(true);
      }));
    })();


    /* ===== swipe gestures ===== */
    (function initDrawerSwipe() {
      let mode = null, active = false, decided = false, startX = 0, startY = 0, w = 0, p = 0, swiped = false;

      function anyModalOpen() {
        return document.querySelector('.bottom-popup-modal.open, .theme-modal.open, .checklist-modal.open, .streak-modal.open, .dashboard-modal.open');
      }

      document.addEventListener('pointerdown', (e) => {
        if (e.target.closest('.bottom-nav, input, textarea, select, .mode-toggle, .cc-sv, .cc-hue')) return;
        if (drawer.classList.contains('open')) mode = 'close';
        else if (!anyModalOpen() && e.clientX < window.innerWidth * 0.25 && e.clientY < window.innerHeight - 100) mode = 'open';
        else return;
        active = true; decided = false;
        startX = e.clientX; startY = e.clientY; w = drawer.offsetWidth; p = mode === 'open' ? 0 : 1;
      });

      document.addEventListener('pointermove', (e) => {
        if (!active) return;
        const dx = e.clientX - startX, dy = e.clientY - startY;
        if (!decided) {
          if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
          const right = mode === 'open' ? dx > 0 : dx < 0;
          if (Math.abs(dx) > Math.abs(dy) * 1.4 && right) {
            decided = true;
            drawer.style.transition = 'none';
            overlay.style.transition = 'none';
            overlay.style.visibility = 'visible';
          } else { active = false; return; }
        }
        p = mode === 'open' ? Math.max(0, Math.min(1, dx / w)) : Math.max(0, Math.min(1, 1 + dx / w));
        drawer.style.transform = `translateX(${(p - 1) * (w + 40)}px)`;
        overlay.style.opacity = String(p);
      });

      function end() {
        if (!active) return;
        active = false;
        if (!decided) return;
        decided = false;
        swiped = true;
        setTimeout(() => { swiped = false; }, 80);
        drawer.style.transition = ''; drawer.style.transform = '';
        overlay.style.transition = ''; overlay.style.opacity = ''; overlay.style.visibility = '';
        const shouldOpen = mode === 'open' ? p > 0.35 : p > 0.65;
        drawer.classList.toggle('open', shouldOpen);
        overlay.classList.toggle('active', shouldOpen);
      }

      document.addEventListener('pointerup', end);
      document.addEventListener('pointercancel', end);
      document.addEventListener('click', (e) => { if (swiped) { e.stopPropagation(); e.preventDefault(); } }, true);
    })();

    (function initCalendarSwipe() {
      const m = dashboardModal;
      let down = false, decided = false, startY = 0, dy = 0;
      m.addEventListener('pointerdown', (e) => {
        if (e.target.closest('button, input, select')) return;
        down = true; decided = false; startY = e.clientY; dy = 0;
      });
      m.addEventListener('pointermove', (e) => {
        if (!down) return;
        dy = e.clientY - startY;
        if (!decided) {
          if (dy < -8) { down = false; return; }
          if (dy < 8) return;
          decided = true;
          try { m.setPointerCapture(e.pointerId); } catch (err) {}
          m.style.transition = 'none';
        }
        m.style.transform = `translate(-50%, calc(-50% + ${Math.max(0, dy)}px))`;
      });
      function end() {
        if (!down) return;
        down = false;
        if (!decided) return;
        decided = false;
        m.style.transition = '';
        m.style.transform = '';
        if (dy > 90) closeAll();          // pulled down: it slides away downward
      }
      m.addEventListener('pointerup', end);
      m.addEventListener('pointercancel', end);
    })();

    function updateCustomTile() {
      const tile = document.getElementById('customTilePreview');
      if (!tile) return;
      let ct = null;
      try { ct = JSON.parse(localStorage.getItem('customTheme')); } catch (e) {}
      if (ct && /^#[0-9a-f]{6}$/i.test(ct.a)) {
        const ca = rgbaOf(ct.a, ct.al == null ? 1 : ct.al), cb2 = ct.b ? rgbaOf(ct.b, ct.bl == null ? 1 : ct.bl) : null;
        tile.style.background = (ct.mode === 'gradient' && cb2) ? `linear-gradient(to bottom, ${ca}, ${cb2})` : ca;
        tile.textContent = '';
      }
    }

    let ccTarget = 'accent';

    function openCustomColorModal(target = 'accent') {
      closeAll();
      ccTarget = target;
      let ct = null;
      try { ct = JSON.parse(localStorage.getItem(target === 'bg' ? 'bgTheme' : 'customTheme')); } catch (e) {}
      if (target === 'bg' && ct && ct.id !== 'custom') ct = null;
      const accent = (ct && ct.a) || (target === 'bg' ? '#0a1226' : (colorPresets[selectedColor]?.accent || '#6366f1'));
      cc.mode = (ct && ct.mode === 'gradient') ? 'gradient' : 'solid';
      const a = hexToRgb(accent) || [99, 102, 241];
      Object.assign(cc.stops[0], rgb2hsv(...a));
      cc.stops[0].al = (ct && ct.al != null) ? ct.al : 1;
      const b = (ct && ct.b && hexToRgb(ct.b)) || [0, 0, 0];
      Object.assign(cc.stops[1], rgb2hsv(...b));
      cc.stops[1].al = (ct && ct.bl != null) ? ct.bl : 1;
      cc.active = 0;
      ccRender();
      ccRenderSaved();
      document.getElementById('customColorModal').classList.add('open');
      overlay.classList.add('active');
    }

    function ccCancel() {
      if (ccTarget === 'bg') openBackgroundPalette(); else openThemePaletteModal();
    }

    function ccApply() {
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
      const gradient = cc.mode === 'gradient';
      if (ccTarget === 'bg') {
        localStorage.setItem('bgTheme', JSON.stringify({ id: 'custom', mode: cc.mode, a: ccHexOf(0), b: gradient ? ccHexOf(1) : null, al: cc.stops[0].al, bl: cc.stops[1].al }));
        runThemeSwitch(() => applyCombinedTheme());
        updateCustomBgTile();
        closeAll();
        return;
      }
      localStorage.setItem('customTheme', JSON.stringify({ mode: cc.mode, a: ccHexOf(0), b: gradient ? ccHexOf(1) : null, al: cc.stops[0].al, bl: cc.stops[1].al }));
      applyCustomPreset();
      selectedColor = 'custom';
      runThemeSwitch(() => applyCombinedTheme());
      updateCustomTile();
      closeAll();
    }

    function selectThemeColor(colorName) {
      selectedColor = colorName;
      runThemeSwitch(() => applyCombinedTheme());
      closeAll();
    }

    function runThemeSwitch(fn) {
      const root = document.documentElement;
      root.classList.add('theme-switching');      // no colour fades: everything flips in one frame
      fn();
      requestAnimationFrame(() => requestAnimationFrame(() => root.classList.remove('theme-switching')));
    }

    function toggleDarkLightMode() {
      runThemeSwitch(() => {
        isLightMode = document.getElementById('themeToggle').checked;
        applyCombinedTheme();
      });
    }

    /* ----- draggable glass Dark / Light toggle ----- */
    const MODE_MIN = 3, MODE_MAX = 51;
    let modeDragging = false;
    function syncModeToggle() {
      const track = document.getElementById('modeToggle');
      const thumb = document.getElementById('modeThumb');
      if (!track || !thumb || modeDragging) return;
      const dark = !document.getElementById('themeToggle').checked;
      track.classList.toggle('dark-active', dark);
      thumb.style.transform = `translateX(${dark ? MODE_MAX - MODE_MIN : 0}px)`;
    }

    function setModeFromToggle(dark) {
      const cb = document.getElementById('themeToggle');
      if (cb.checked === !dark) { syncModeToggle(); return; }
      cb.checked = !dark;
      toggleDarkLightMode();
      syncModeToggle();
    }

    (function initModeToggle() {
      const track = document.getElementById('modeToggle');
      const thumb = document.getElementById('modeThumb');
      const cb = document.getElementById('themeToggle');
      let dragging = false, moved = false, startX = 0, startClientX = 0, curX = MODE_MIN, startDark = true;

      function pos() { return cb.checked ? MODE_MIN : MODE_MAX; }

      function applyMode(dark) {
        if (cb.checked === !dark) return;
        runThemeSwitch(() => {
          cb.checked = !dark;
          isLightMode = cb.checked;
          applyCombinedTheme();
        });
      }

      function begin(e) {
        dragging = true; moved = false; modeDragging = true;
        startDark = !cb.checked;
        curX = pos();
        startClientX = e.clientX;
        startX = e.clientX - curX;
        try { track.setPointerCapture(e.pointerId); } catch (err) {}
      }

      function move(e) {
        if (!dragging) return;
        if (!moved && Math.abs(e.clientX - startClientX) < 2) return;
        if (!moved) { moved = true; thumb.classList.add('dragging'); }
        if (e.cancelable) e.preventDefault();
        curX = Math.max(MODE_MIN, Math.min(MODE_MAX, e.clientX - startX));
        thumb.style.transform = `translateX(${curX - MODE_MIN}px)`;
        const dark = curX > (MODE_MIN + MODE_MAX) / 2;
        track.classList.toggle('dark-active', dark);
        applyMode(dark);                       // changes as soon as the thumb crosses the middle
      }

      function end(e) {
        if (!dragging) return;
        dragging = false;
        thumb.classList.remove('dragging');
        try { track.releasePointerCapture(e.pointerId); } catch (err) {}
        const tap = !moved && e.type !== 'pointercancel';
        const finalDark = tap ? !startDark : (e.type === 'pointercancel' ? startDark : curX > (MODE_MIN + MODE_MAX) / 2);
        modeDragging = false;
        applyMode(finalDark);
        syncModeToggle();
      }

      track.addEventListener('pointerdown', begin);
      track.addEventListener('pointermove', move);
      track.addEventListener('pointerup', end);
      track.addEventListener('pointercancel', end);
    })();

    function openThemePaletteModal() {
      closeAll();
      themePaletteModal.classList.add('open');
      overlay.classList.add('active');
    }

    function openAddTaskModal() {
      closeAll();
      document.getElementById('newStreakModal')?.classList.remove('open');
      overlay.classList.remove('active');
      newTaskInput.value = '';
      addTaskModal.classList.add('open');
      overlay.classList.add('active');
      setTimeout(() => newTaskInput.focus(), 200);
    }

    function confirmAddNewTask() {
      const taskName = newTaskInput.value.trim();
      if (taskName !== "") {
        tasks.push({name: taskName, checklist: []});
        saveAndReloadTasks();
        closeAll();
      }
    }

    newTaskInput.addEventListener('keyup', function(e) {
      if (e.key === 'Enter') {
        confirmAddNewTask();
      }
    });

    function openConfirmDeleteAllModal() {
      closeAll();
      confirmDeleteAllModal.classList.add('open');
      overlay.classList.add('active');
    }

    function confirmDeleteAllTasks() {
      tasks = [];
      dayTaskHistory = {};
      localStorage.setItem('dayTaskHistory', '{}');
      cancelSelectMode();
      saveAndReloadTasks();
      closeAll();
    }

    let lastPlusPop = 0;

    function popAddButton() {
      const gb = document.getElementById('glassButton');
      const tasksViewEl = document.getElementById('tasksView');
      if (!gb || !tasksViewEl.classList.contains('active-page')) return;
      const now = Date.now();
      if (now - lastPlusPop < 600) return;   // never pop twice in a row
      lastPlusPop = now;
      gb.classList.remove('plus-pop');
      void gb.offsetWidth;
      gb.classList.add('plus-pop');
      gb.addEventListener('animationend', () => gb.classList.remove('plus-pop'), { once: true });
    }

    function syncAddButtonVisibility() {
      const gb = document.getElementById('glassButton');
      if (!gb) return;
      const wasHidden = gb.style.display === 'none';
      gb.style.display = isSelectMode ? 'none' : '';
      if (wasHidden && !isSelectMode) popAddButton();
    }

    function enableSelectMode() {
      isSelectMode = true;
      document.getElementById('deleteActionBar').style.display = 'flex';
      syncAddButtonVisibility();
      renderTasks();
      closeAll();
    }

    function cancelSelectMode() {
      isSelectMode = false;
      document.getElementById('deleteActionBar').style.display = 'none';
      syncAddButtonVisibility();
      renderTasks();
    }

    function deleteSelectedTasks() {
      const selectedCheckboxes = document.querySelectorAll('.delete-select-checkbox:checked');
      if (selectedCheckboxes.length === 0) {
        openDeleteOptionsMenu();
        return;
      }

      const indicesToDelete = Array.from(selectedCheckboxes).map(cb => parseInt(cb.getAttribute('data-index')));
      tasks = tasks.filter((_, idx) => !indicesToDelete.includes(idx));
      dayTaskHistory = {};
      localStorage.setItem('dayTaskHistory', '{}');

      cancelSelectMode();
      saveAndReloadTasks();
    }

    function openDeleteTaskConfirm() {
      if (activeTaskIndex === null || !tasks[activeTaskIndex]) return;
      closeAll();
      document.getElementById('deleteTaskConfirmModal').classList.add('open');
      overlay.classList.add('active');
    }

    function deleteTask() {
      if (activeTaskIndex === null) return;
      tasks.splice(activeTaskIndex, 1);
      activeTaskIndex = null;
      dayTaskHistory = {};
      localStorage.setItem('dayTaskHistory', '{}');
      saveAndReloadTasks();
      closeAll();
    }

    let rewardFinishedDay = null;

    function showFinalReward() {
      rewardFinishedDay = currentDay;
      const d = document.getElementById('rewardDescription');
      if (d) d.textContent = `You completed your ${TOTAL_DAYS}-day challenge! Tap Finished to restore your streak to Day 1 and begin again.`;
      document.getElementById('rewardModal').classList.add('open');
      overlay.classList.add('active');
    }

    function chooseRewardAction(action) {
      if (action === 'finished') {
        closeAll();
        restoreStreakToOneDay();
      }
    }

    function restoreStreakToOneDay() {
      currentDay = 1;
      highestUnlockedDay = 1;
      completedDays = [];
      dayTaskHistory = {};
      localStorage.setItem('completedDays', '[]');
      localStorage.setItem('highestUnlockedDay', '1');
      localStorage.setItem('challengeDay', '1');
      localStorage.setItem('dayTaskHistory', '{}');
      saveAndReloadTasks();
      renderProgress();
      switchTab('home');
      TOTAL_DAYS = 0;
      localStorage.setItem('streakDays', '0');
      openNewStreakModal('restore');
    }

    function openRestoreConfirmModal() {
      closeAll();
      document.getElementById('restoreConfirmModal').classList.add('open');
      overlay.classList.add('active');
      switchRestoreLens('cancel');
    }

    function switchRestoreLens(which) {
      document.querySelectorAll('.restore-choice').forEach(b => b.classList.remove('active'));
      const b = document.getElementById(which === 'ok' ? 'restoreOkBtn' : 'restoreCancelBtn');
      b.classList.add('active');
    }

    function chooseRestoreAction(action) {
      if (action === 'cancel') {
        switchRestoreLens('cancel');
        closeAll();
        return;
      }

      switchRestoreLens('ok');
      if (restoreFlowTimer) clearTimeout(restoreFlowTimer);
      restoreFlowTimer = null;

      tasks = [];
      activeTaskIndex = null;
      activeChecklistIndex = null;
      isSelectMode = false;
      completedDays = [];
      dayTaskHistory = {};
      currentDay = 0;
      highestUnlockedDay = 0;
      TOTAL_DAYS = 0;

      localStorage.setItem('userTasks', '[]');
      localStorage.setItem('completedDays', '[]');
      localStorage.setItem('highestUnlockedDay', '0');
      localStorage.setItem('challengeDay', '0');
      localStorage.setItem('dayTaskHistory', '{}');
      localStorage.setItem('streakDays', '0');

      const input = document.getElementById('streakDaysInput');
      if (input) input.value = 0;
      const display = document.getElementById('streakDaysDisplay');
      if (display) display.textContent = '0';

      closeAll();
      renderTasks();
      renderProgress();
      updateLiquidNav(activeTab === 'tasks' ? 0 : 1);

      openNewStreakModal('restore');
    }

    function openNewStreakModal(mode = 'restore') {
      closeAll();
      newStreakMode = mode;
      const title = document.getElementById('newStreakModalTitle');
      const saveBtn = document.getElementById('newStreakSaveBtn');
      if (title) title.textContent = mode === 'edit' ? 'Edit Your Streak' : 'Choose Your Streak';
      if (saveBtn) saveBtn.textContent = 'Save';

      const current = TOTAL_DAYS > 0 ? TOTAL_DAYS : 7;
      const buttons = Array.from(document.querySelectorAll('#newStreakPresets .new-streak-btn'));
      const matching = buttons.find(b => Number(b.textContent.replace(/\D/g, '')) === current);
      selectNewStreak(current, matching || buttons[0]);

      if (mode === 'restore') {
        document.getElementById('newStreakInput').value = 7;
        const first = buttons[0];
        if (first) selectNewStreak(7, first);
      }

      document.getElementById('newStreakModal').classList.add('open');
      overlay.classList.add('active');
    }

    function selectNewStreak(days, btn) {
      const group = document.getElementById('newStreakPresets');
      const buttons = group.querySelectorAll('.new-streak-btn');
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const idx = Array.from(buttons).indexOf(btn);
      const lens = document.getElementById('newStreakGlass');
      const row = Math.floor(idx / 2), col = idx % 2;
      lens.style.transform = `translate(${col * 100}%, ${row * 58}px)`;
      document.getElementById('newStreakInput').value = days;
    }

    function applyNewCustomStreak() {
      if (document.activeElement && typeof document.activeElement.blur === 'function') document.activeElement.blur();
      const n = Math.max(1, Math.floor(Number(document.getElementById('newStreakInput').value) || 1));
      applyNewStreak(n);
    }

    function applyNewStreak(days) {
      const n = Math.max(1, Math.floor(Number(days) || 1));
      const keepProgress = newStreakMode === 'edit';   // Settings > Streak Days: keep the days already done
      TOTAL_DAYS = n;
      if (keepProgress) {
        currentDay = Math.max(1, Math.min(currentDay, n));
        highestUnlockedDay = Math.max(1, Math.min(highestUnlockedDay, n));
        completedDays = completedDays.filter(d => d <= n);
      } else {
        currentDay = 1;
        highestUnlockedDay = 1;
        completedDays = [];
        localStorage.setItem('streakStart', String(Date.now()));   // the 24-hour day clock starts now
      }

      localStorage.setItem('streakDays', String(n));
      localStorage.setItem('challengeDay', String(currentDay));
      localStorage.setItem('highestUnlockedDay', String(highestUnlockedDay));
      localStorage.setItem('completedDays', JSON.stringify(completedDays));

      const input = document.getElementById('streakDaysInput');
      if (input) input.value = TOTAL_DAYS;
      const display = document.getElementById('streakDaysDisplay');
      if (display) display.textContent = TOTAL_DAYS;

      renderProgress();
      renderTasks();
      closeAll();
      if (!keepProgress) switchTab('home');
      newStreakMode = 'edit';
    }

    function openEditStreakModal() {
      openNewStreakModal('edit');
    }

    function saveAndReloadTasks() {
      localStorage.setItem('userTasks', JSON.stringify(tasks));
      renderTasks();
    }

    function updateTaskStats() {
      try { scheduleNativeSoon(false); } catch (e) {}   // phone reminders follow the task state
      // Percent = checked checklist items / all checklist items (across every task)
      let totalItems = 0;
      let doneItems = 0;
      let doneTasks = 0;
      const totalTasks = tasks.length;

      tasks.forEach(task => {
        const items = task.checklist || [];
        const done = items.filter(x => x.done).length;
        totalItems += items.length;
        doneItems += done;
        if (items.length > 0 && done === items.length) doneTasks++;
      });

      const percentage = totalItems > 0 ? Math.round((doneItems / totalItems) * 100) : 0;
      const taskPercentage = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;

      const percentBadge = document.getElementById('percentageBadge');
      const scoreBadge = document.getElementById('scoreBadge');
      percentBadge.querySelector('.charge-text').textContent = `${percentage}%`;
      scoreBadge.querySelector('.charge-text').textContent = `${doneTasks}/${totalTasks}`;

      percentBadge.style.setProperty('--fill', `${percentage}%`);
      percentBadge.classList.toggle('filled', percentage >= 45);
      scoreBadge.style.setProperty('--fill', `${taskPercentage}%`);
      scoreBadge.classList.toggle('filled', taskPercentage >= 45);
    }

    function completedCount() {
      if (TOTAL_DAYS <= 0) return 0;
      return completedDays.filter(d => d >= 1 && d <= TOTAL_DAYS).length;
    }

    function renderProgress() {
      if (typeof scheduleSoon === 'function') scheduleSoon();
      if (TOTAL_DAYS <= 0) {
        TOTAL_DAYS = 0;
        currentDay = 0;
      } else {
        if (currentDay > TOTAL_DAYS) currentDay = TOTAL_DAYS;
        if (currentDay < 1) currentDay = 1;
      }

      const doneDays = completedCount();
      dayCounter.textContent = doneDays;
      const streakTitleDays = document.getElementById('streakTitleDays');
      if (streakTitleDays) streakTitleDays.textContent = TOTAL_DAYS;

      const percentage = TOTAL_DAYS > 0 ? (doneDays / TOTAL_DAYS) * 100 : 0;
      const ringOffset = RING_CIRCUMFERENCE - (percentage / 100) * RING_CIRCUMFERENCE;
      ringFill.style.strokeDashoffset = ringOffset;
      ringEdge.style.strokeDashoffset = ringOffset;
      ringFill.style.opacity = ringEdge.style.opacity = percentage > 0 ? '1' : '0';

      localStorage.setItem('challengeDay', String(currentDay));
      buildStreakCalendar();
    }

    function buildStreakCalendar() {
      const sig = [TOTAL_DAYS, currentDay, highestUnlockedDay, completedDays.join(',')].join('|');
      if (sig === calendarSig && calendarGrid.querySelector('.day-card')) return;   // unchanged: no rebuild, no flash
      calendarSig = sig;
      calendarGrid.innerHTML = '';

      let dayGlassLens = document.createElement('div');
      dayGlassLens.className = 'day-glass-lens';
      dayGlassLens.id = 'dayGlassLens';
      calendarGrid.appendChild(dayGlassLens);

      let activeCardEl = null;

      for (let i = 1; i <= TOTAL_DAYS; i++) {
        const card = document.createElement('div');
        let cardStatusClass = '';

        if (completedDays.includes(i) || i < currentDay) {
          cardStatusClass = 'completed';
        }

        if (i === currentDay) {
          cardStatusClass += ' active';
        }

        const isLocked = i > highestUnlockedDay && i !== currentDay && !cardStatusClass.includes('completed');
        if (isLocked) cardStatusClass += ' locked';

        card.className = `day-card ${cardStatusClass.trim()}`;
        card.innerHTML = `
          <div class="day-card-num">${i}</div>
          <div class="day-card-lbl">DAY</div>
          ${isLocked ? '<svg class="lock-ico" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17 9V7a5 5 0 0 0-10 0v2H5v12h14V9h-2zM9 7a3 3 0 0 1 6 0v2H9V7z"/></svg>' : ''}
        `;

        card.onclick = () => selectDay(i);
        calendarGrid.appendChild(card);

        if (i === currentDay) {
          activeCardEl = card;
        }
      }

      setTimeout(() => {
        if (activeCardEl && dayGlassLens) {
          dayGlassLens.style.width = activeCardEl.offsetWidth + 'px';
          dayGlassLens.style.height = activeCardEl.offsetHeight + 'px';
          dayGlassLens.style.transform = `translate(${activeCardEl.offsetLeft}px, ${activeCardEl.offsetTop}px)`;
        }
      }, 50);
    }

    /* drag the glass between Daily Task / Home / Daily Streak */
    (function initNavDrag() {
      const nav = document.querySelector('.bottom-nav');
      const lens = document.getElementById('glassLens');
      const items = Array.from(nav.querySelectorAll('.nav-item'));
      let down = false, dragging = false, startX = 0, startIdx = 1, lensW = 0, pos = 0, hover = 1, opened = 1, suppress = false;

      function currentIndex() {
        if (document.getElementById('streakModal').classList.contains('open')) return 2;
        return activeTab === 'tasks' ? 0 : 1;
      }

      function iconState(i) {
        items.forEach((x, k) => {
          x.classList.toggle('active', k === i);
          x.classList.toggle('stroke-icon', k !== i);
        });
      }

      function openIdx(i) {
        opened = i;
        if (i === 2) openStreakModal();
        else switchTab(i === 0 ? 'tasks' : 'home');
      }

      nav.addEventListener('pointerdown', (e) => {
        down = true; dragging = false;
        startX = e.clientX;
        startIdx = hover = opened = currentIndex();
        lensW = lens.offsetWidth;
        pos = startIdx * lensW;
      });

      nav.addEventListener('pointermove', (e) => {
        if (!down) return;
        const dx = e.clientX - startX;
        if (!dragging) {
          if (Math.abs(dx) < 4) return;
          dragging = true;
          navDragging = true;
          try { nav.setPointerCapture(e.pointerId); } catch (err) {}
          lens.classList.add('zoom');
          nav.classList.add('dragging');
        }
        pos = Math.max(0, Math.min(2 * lensW, startIdx * lensW + dx));
        lens.style.transform = `translateX(${pos / 1.05}px)`;   // the 1.05 zoom also scales the travel, so compensate
        const idx = Math.max(0, Math.min(2, Math.round(pos / lensW)));
        if (idx !== hover) {
          hover = idx;
          iconState(idx);
          openIdx(idx);          // the page opens while the glass is still moving
        }
      });

      function release(e) {
        if (!down) return;
        down = false;
        if (!dragging) return;
        dragging = false;
        try { nav.releasePointerCapture(e.pointerId); } catch (err) {}
        lens.classList.remove('zoom');
        nav.classList.remove('dragging');
        navDragging = false;
        suppress = true;
        setTimeout(() => { suppress = false; }, 60);
        const idx = Math.max(0, Math.min(2, Math.round(pos / lensW)));
        if (idx !== opened) openIdx(idx);
        iconState(idx);
        lens.style.transform = `translateX(${idx * 100}%)`;
      }

      nav.addEventListener('pointerup', release);
      nav.addEventListener('pointercancel', release);
      nav.addEventListener('click', (e) => { if (suppress) { e.stopPropagation(); e.preventDefault(); } }, true);
    })();

    function setActiveNavTab(el, index) {
      document.querySelectorAll('.bottom-nav .nav-item').forEach(x => {
        x.classList.remove('active');
        x.classList.add('stroke-icon');
      });
      el.classList.add('active');
      el.classList.remove('stroke-icon');

      const lens = document.getElementById('glassLens');
      if (lens) lens.style.transform = `translateX(${index * 100}%)`;

      if (index === 0) {
        switchTab('tasks');
      } else if (index === 1) {
        switchTab('home');
      } else if (index === 2) {
        openStreakModal();
      }
    }

    function updateLiquidNav(index) {
      document.querySelectorAll('.bottom-nav .nav-item').forEach(x => {
        x.classList.remove('active');
        x.classList.add('stroke-icon');
      });
      const items = document.querySelectorAll('.bottom-nav .nav-item');
      if (items[index]) {
        items[index].classList.add('active');
        items[index].classList.remove('stroke-icon');
      }
      const lens = document.getElementById('glassLens');
      if (lens && !navDragging) lens.style.transform = `translateX(${index * 100}%)`;
    }

    function switchTab(tab) {
      const prevTab = activeTab;
      activeTab = tab === 'tasks' ? 'tasks' : 'home';
      closeAll();
      updateLiquidNav(activeTab === 'tasks' ? 0 : 1);
      cancelSelectMode();

      document.getElementById('homeView').classList.toggle('active-page', activeTab === 'home');
      document.getElementById('tasksView').classList.toggle('active-page', activeTab === 'tasks');
      document.getElementById('topTrashBtn').style.display = activeTab === 'tasks' ? 'flex' : 'none';
      document.getElementById('topCalendarBtn').style.display = activeTab === 'tasks' ? 'none' : 'flex';

      renderTasks();
      updateTaskStats();
      if (activeTab === 'tasks' && prevTab !== 'tasks') popAddButton();
    }

    function openStreakModal() {
      closeAll();
      streakModal.classList.add('open');
      const streakNav = document.getElementById('navStreak');
      streakNav.classList.add('active');
      streakNav.classList.remove('stroke-icon');
      const lens = document.getElementById('glassLens');
      if (lens && !navDragging) lens.style.transform = `translateX(200%)`;
      buildStreakCalendar();
    }

    function closeStreakWithX() {
      streakModal.classList.remove('open');
      if (activeTab === 'home') updateLiquidNav(1);
      else updateLiquidNav(0);
    }

    function openDeleteOptionsMenu() {
      closeAll();
      deleteOptionsModal.classList.add('open');
      overlay.classList.add('active');
    }

    function openDrawer() {
      closeAll();
      drawer.classList.add('open');
      overlay.classList.add('active');
    }

    function closeAll() {
      if (restoreFlowTimer) {
        clearTimeout(restoreFlowTimer);
        restoreFlowTimer = null;
      }
      drawer.classList.remove('open');
      streakModal.classList.remove('open');
      dashboardModal.classList.remove('open');
      themePaletteModal.classList.remove('open');
      deleteOptionsModal.classList.remove('open');
      confirmDeleteAllModal.classList.remove('open');
      submitModal.classList.remove('open');
      addTaskModal.classList.remove('open');
      streakAlertModal.classList.remove('open');

      document.getElementById('parentOptionsModal')?.classList.remove('open');
      document.getElementById('editTaskModal')?.classList.remove('open');
      document.getElementById('checklistModal')?.classList.remove('open');
      document.getElementById('checklistItemOptionsModal')?.classList.remove('open');
      document.getElementById('checklistItemModal')?.classList.remove('open');
      document.getElementById('deleteTaskConfirmModal')?.classList.remove('open');
      document.getElementById('deleteChecklistConfirmModal')?.classList.remove('open');
      document.getElementById('rewardModal')?.classList.remove('open');
      document.getElementById('restoreConfirmModal')?.classList.remove('open');
      document.getElementById('newStreakModal')?.classList.remove('open');
      document.getElementById('streakExtendModal')?.classList.remove('open');
      document.getElementById('customColorModal')?.classList.remove('open');
      document.getElementById('themeChooserModal')?.classList.remove('open');
      document.getElementById('notifPermModal')?.classList.remove('open');
      document.getElementById('bgPaletteModal')?.classList.remove('open');

      overlay.classList.remove('active');
    }

    function saveStreakDays(value) {
      const n = Math.max(1, Math.floor(Number(value) || 30));
      TOTAL_DAYS = n;
      currentDay = Math.min(currentDay, TOTAL_DAYS);
      highestUnlockedDay = Math.min(highestUnlockedDay, TOTAL_DAYS);
      localStorage.setItem('streakDays', String(TOTAL_DAYS));
      document.getElementById('streakDaysInput').value = TOTAL_DAYS;
      renderProgress();
    }

    applyCombinedTheme();
    updateCustomTile();
    updateCustomBgTile();
    document.getElementById('streakDaysInput').value = TOTAL_DAYS;
    const initialDisplay = document.getElementById('streakDaysDisplay');
    if (initialDisplay) initialDisplay.textContent = TOTAL_DAYS;
    renderTasks();
  
