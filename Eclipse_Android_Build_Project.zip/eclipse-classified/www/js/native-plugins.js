/*
 * Plain-browser preview fallback. The Android build preparation script replaces
 * this file with the bundled @capacitor/local-notifications bridge.
 */
