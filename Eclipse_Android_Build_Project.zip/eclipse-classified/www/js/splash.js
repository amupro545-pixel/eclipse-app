/* Eclipse - opening animation script (ring, typing, caret, neon) */

    (function () {
      var word = "ECLIPSE";
      var splash = document.getElementById('eclipse-splash');
      document.documentElement.classList.add('splash-on');   // the app is not painted while the opening plays

      // colour follows the selected theme
      var ACCENTS = { black: '#6366f1', white: '#4f46e5', red: '#ef4444', blue: '#3b82f6', green: '#10b981', yellow: '#eab308' };
      var themeName = localStorage.getItem('appColorTheme');
      var accent = ACCENTS[themeName] || ACCENTS.black;
      if (themeName === 'custom') {
        try { var ct = JSON.parse(localStorage.getItem('customTheme')); if (ct && /^#[0-9a-f]{6}$/i.test(ct.a)) accent = ct.a; } catch (e) {}
      }
      (function () {
        var c = parseInt(accent.slice(1), 16), r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        function lin(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
        var lum = 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
        if (lum < 0.1) accent = '#ffffff';    // a black / very dark icon colour would vanish on the black opening: use white
      })();
      (function paint() {
        var n = parseInt(accent.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
        function mix(a) { return 'rgb(' + Math.round(r + (255 - r) * a) + ',' + Math.round(g + (255 - g) * a) + ',' + Math.round(b + (255 - b) * a) + ')'; }
        splash.style.setProperty('--es-rgb', r + ',' + g + ',' + b);
        var set = function (id, c) { document.getElementById(id).setAttribute('stop-color', c); };
        set('esStop1', accent); set('esStop2', mix(0.4)); set('esStop3', mix(0.92));
        set('esSpec1', '#ffffff'); set('esSpec2', mix(0.5)); set('esSpec3', accent);
      })();
      var container = document.getElementById('es-word');
      var ring = document.getElementById('es-ring');
      var glass = document.getElementById('es-glass');
      ring.style.filter = 'none';   // no filter work while the ring is turning

      function ease(u) { return u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2; }

      // one shared neon value drives the ring, the glass box and the letters
      function neon(from, to, ms, done) {
        var t0 = performance.now();
        (function step(now) {
          var u = Math.min(1, (now - t0) / ms);
          splash.style.setProperty('--es-n', (from + (to - from) * ease(u)).toFixed(4));
          if (u < 1) requestAnimationFrame(step); else if (done) done();
        })(t0);
      }

      function run() {
        var i = 0;
        var caret = document.createElement('span');          // the typing cursor, in the theme colour
        caret.className = 'es-caret';
        container.appendChild(caret);
        var typing = setInterval(function () {
          if (i < word.length) {
            var span = document.createElement('span');
            span.className = 'es-char';
            span.textContent = word[i];
            container.insertBefore(span, caret);
            i++;
          } else {
            clearInterval(typing);
            setTimeout(function () {
              caret.classList.add('es-caret-out');             // cursor fades away when the word is done
              setTimeout(function () {
                if (caret.parentNode) caret.parentNode.removeChild(caret);
                ring.classList.add('es-paused');               // the ring stops
                ring.style.filter = '';
                setTimeout(function () {
                  neon(0, 1, 1500, function () {               // neon fades IN
                    // the app is drawn now, behind the opaque opening, so the final fade is just one smooth layer
                    document.documentElement.classList.remove('splash-on');
                    neon(1, 0, 900, function () {              // neon fades out quickly
                      splash.style.pointerEvents = 'none';
                      splash.style.opacity = '0';              // and the whole opening disappears right after
                      setTimeout(function () {
                        if (splash.parentNode) splash.parentNode.removeChild(splash);
                        document.dispatchEvent(new Event('splashdone'));
                      }, 400);
                    });
                  });
                }, 150);
              }, 320);
            }, 450);
          }
        }, 340);
      }

      setTimeout(run, 500);
    })();
  