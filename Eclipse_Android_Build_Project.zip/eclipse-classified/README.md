# Eclipse — Android app project

This project packages the provided Eclipse offline habit/streak tracker for Android while retaining the supplied task tracker, visual design, splash animation, themes, storage logic, and reminder rules. App content and styling are preserved. The Android packaging adds only the Capacitor bridge required for the existing Local Notifications code to reach the native Android plugin.

## Build a real Android APK with GitHub Actions

The source ZIP cannot contain a precompiled APK because Android's SDK/Gradle build system and dependencies must be downloaded by a build environment. This repository includes a workflow that builds the APK for you.

1. Extract this ZIP.
2. Upload the **contents** of the extracted `eclipse-classified` folder into a new GitHub repository. Use a repository named `eclipse-classified`; set its default branch to `main` if prompted. Keep the `.github` folder when uploading.
3. Open the repository's **Actions** tab and choose **Build Eclipse Android APK**. If GitHub asks, enable Actions, then select **Run workflow**. A push to `main` or `master` also starts a build automatically.
4. When the run completes successfully, open that run and download the artifact named **Eclipse-Android-APK**. Extract the artifact ZIP to get `app-debug.apk`.
5. Move `app-debug.apk` to the Android phone and tap it to install. If Android blocks installation, allow your file manager/browser to install unknown apps, then try again.
6. Open Eclipse and allow notifications. On Android 12+ open the app's system settings and allow **Alarms & reminders** (exact wording may vary); set battery use to **Unrestricted** if reminders are delayed.

## Build locally (requires Android Studio / Android SDK)

From this folder run:

```bash
npm install
npm run prepare:android
npx cap add android
node tools/patch-android-manifest.mjs
npx cap sync android
cd android
./gradlew assembleDebug
```

The APK is written to `android/app/build/outputs/apk/debug/app-debug.apk`.

## Important behavior note

The tracker itself works offline. The first APK build requires a network connection to download Node/Capacitor and Android build dependencies. After installation, the app's local interface and scheduled reminders do not require an app server. Android may still apply exact-alarm and battery restrictions unless the user allows them in system settings.

The supplied `www/html/notification.html` and `www/html/splash.html` files are retained unchanged as reference copies, as in the ZIP. The live app markup remains `www/index.html`.
