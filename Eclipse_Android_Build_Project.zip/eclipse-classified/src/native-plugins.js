/*
 * Native-only Capacitor plugin bridge for the existing, non-bundled Eclipse app.
 * The application code already uses window.Capacitor.Plugins.LocalNotifications.
 * This bridge exposes the official Capacitor 6 plugin at that legacy location
 * without changing the app's UI or reminder logic.
 */
import { LocalNotifications } from '@capacitor/local-notifications';

const capacitor = window.Capacitor;
if (capacitor && typeof capacitor.isNativePlatform === 'function' && capacitor.isNativePlatform()) {
  capacitor.Plugins = capacitor.Plugins || {};
  capacitor.Plugins.LocalNotifications = LocalNotifications;
}
