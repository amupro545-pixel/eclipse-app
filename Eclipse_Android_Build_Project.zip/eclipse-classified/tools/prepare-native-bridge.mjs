import { build } from 'esbuild';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = process.cwd();
const entry = resolve(root, 'src/native-plugins.js');
const output = resolve(root, 'www/js/native-plugins.js');
const indexPath = resolve(root, 'www/index.html');

await build({
  entryPoints: [entry],
  outfile: output,
  bundle: true,
  platform: 'browser',
  format: 'iife',
  target: ['es2020'],
  legalComments: 'none',
  minify: false,
});

let html = await readFile(indexPath, 'utf8');
const bridgeTag = '<script src="js/native-plugins.js"></script>';
if (!html.includes(bridgeTag)) {
  const appTag = '<script src="js/app.js"></script>';
  if (!html.includes(appTag)) {
    throw new Error('Could not find the app.js script tag in www/index.html; refusing to modify unknown markup.');
  }
  html = html.replace(appTag, `${bridgeTag}\n${appTag}`);
  await writeFile(indexPath, html, 'utf8');
}
console.log('Prepared the Capacitor Local Notifications bridge and HTML load order.');
