import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const manifestPath = resolve('android/app/src/main/AndroidManifest.xml');
let xml;
try {
  xml = await readFile(manifestPath, 'utf8');
} catch {
  console.error('Android project is missing. Run "npx cap add android" first.');
  process.exit(1);
}

const permissions = [
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.SCHEDULE_EXACT_ALARM',
  'android.permission.RECEIVE_BOOT_COMPLETED',
  'android.permission.VIBRATE',
];
const missing = permissions.filter((p) => !xml.includes(`android:name="${p}"`));
if (missing.length === 0) {
  console.log('All Eclipse notification permissions are already present.');
  process.exit(0);
}
const manifestOpen = /<manifest\b[^>]*>/;
if (!manifestOpen.test(xml)) throw new Error('AndroidManifest.xml has no valid <manifest> opening tag.');
const additions = missing.map((p) => `    <uses-permission android:name="${p}" />`).join('\n');
xml = xml.replace(manifestOpen, (tag) => `${tag}\n${additions}`);
await writeFile(manifestPath, xml, 'utf8');
console.log(`Added Android permissions: ${missing.join(', ')}`);
